using System;
using System.Runtime.CompilerServices;
using UnityEngine;

public class GrenadeProjectile : MonoBehaviour
{
    [SerializeField] private Transform grenadeExplosionVfxPrefab; // 手榴弹爆炸特效预制体
    [SerializeField] private TrailRenderer trailRenderer;          // 轨迹渲染器
    [SerializeField] private AnimationCurve arcYAnimationCurve;    // 控制手榴弹投掷弧线的Y轴动画曲线

    // 静态事件：当任意手榴弹爆炸时触发
    public static event EventHandler OnAnyGrenadeExploded;

    private Vector3 targetPosition;          // 目标位置（爆炸位置）
    private Action OnGrenadeBehaviourComplete; // 手榴弹行为完成后的回调

    private float totalDistance;  // 手榴弹从起点到目标点的总距离
    private Vector3 positionXZ;   // 手榴弹在XZ平面上的位置（忽略Y轴）

    private void Update()
    {
        // 计算朝向目标的方向向量（在XZ平面上）
        Vector3 moveDir = (targetPosition - positionXZ).normalized;

        // 移动参数设置
        float moveSpeed = 15f;
        // 在XZ平面上更新位置
        positionXZ += moveDir * moveSpeed * Time.deltaTime;

        // 判断是否到达目标的距离阈值
        float reachedTargetDistance = .2f;
        float distance = Vector3.Distance(positionXZ, targetPosition);

        // 计算手榴弹的抛物线高度
        float maxHeight = totalDistance / 3f;  // 最大高度与距离成正比
        float distanceNormalized = 1 - distance / totalDistance; // 标准化距离（1->0）
        // 通过动画曲线和最大高度计算当前Y轴位置
        float positionY = arcYAnimationCurve.Evaluate(distanceNormalized) * maxHeight;

        // 应用最终位置（保持XZ移动，叠加Y轴高度）
        transform.position = new Vector3(positionXZ.x, positionY, positionXZ.z);

        // 检查是否到达目标位置
        if (Vector3.Distance(positionXZ, targetPosition) < reachedTargetDistance)
        {
            // --- 爆炸伤害处理 ---
            float damageRadius = 3f; // 爆炸伤害半径
            // 获取爆炸范围内的所有碰撞体
            Collider[] colliderArray = Physics.OverlapSphere(targetPosition, damageRadius);

            foreach (Collider collider in colliderArray)
            {
                // 对范围内的单位造成伤害
                if (collider.TryGetComponent<Unit>(out Unit targetUnit))
                {
                    targetUnit.Damage(30);
                }

                // 对范围内的可销毁箱子造成伤害
                if (collider.TryGetComponent<DestructableCrate>(out DestructableCrate destructableCrate))
                {
                    destructableCrate.Damage();
                }
            }

            // 触发手榴弹爆炸事件
            OnAnyGrenadeExploded?.Invoke(this, EventArgs.Empty);

            // 分离轨迹渲染器，使其自然消失
            trailRenderer.transform.parent = null;
            // 生成爆炸特效（在目标位置上方1单位）
            Instantiate(grenadeExplosionVfxPrefab, targetPosition + Vector3.up * 1f, Quaternion.identity);
            
            // 销毁手榴弹本体
            Destroy(gameObject);

            // 执行回调通知手榴弹行为完成
            OnGrenadeBehaviourComplete();
        }
    }

    /// <summary>
    /// 初始化手榴弹参数
    /// </summary>
    /// <param name="targetGridPosition">目标网格位置</param>
    /// <param name="OnGrenadeBehaviourComplete">行为完成回调</param>
    public void Setup(GridPosition targetGridPosition, Action OnGrenadeBehaviourComplete)
    {
        this.OnGrenadeBehaviourComplete = OnGrenadeBehaviourComplete;
        // 将网格位置转换为世界坐标
        targetPosition = LevelGrid.Instance.GetWorldPosition(targetGridPosition);

        // 初始化XZ平面位置（忽略初始高度）
        positionXZ = transform.position;
        positionXZ.y = 0;
        // 计算总移动距离
        totalDistance = Vector3.Distance(positionXZ, targetPosition);
    }
}