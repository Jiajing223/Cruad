using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletProjectile : MonoBehaviour
{
    [SerializeField] private TrailRenderer trailRenderer;
    [SerializeField] private Transform BulletHitVfxPrefab;


    private Vector3 targetPosition;

    public void Setup(Vector3 targetPos)
    {
        this.targetPosition = targetPos;
    }


    private void Update()
    {
        Vector3 moveDirection = (targetPosition - transform.position).normalized;

        float distanceBeforeMove = Vector3.Distance(transform.position, targetPosition);


        float speed = 200f;
        transform.position += moveDirection * speed * Time.deltaTime;

        float distanceAfterMove = Vector3.Distance(transform.position, targetPosition);

        // Destroy the bullet if it has reached or passed the target position
        if (distanceAfterMove > distanceBeforeMove)
        {
            transform.position = targetPosition;

            trailRenderer.transform.parent = null;

            Destroy(gameObject);

            Instantiate(BulletHitVfxPrefab, targetPosition, Quaternion.identity);
        }

    }
}
