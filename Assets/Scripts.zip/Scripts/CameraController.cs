using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;
public class CameraController : MonoBehaviour
{
    public struct CameraState
    {
        public Transform Follow;
        public Transform LookAt;
        public Vector3 Position;
        public Quaternion Rotation;
    }

    private CameraState? savedState = null;

    [SerializeField] private CinemachineVirtualCamera cinemachineVirtualCamera;
    private const float MIN_FOLLOW_OFFSET = 2f;
    private const float MAX_FOLLOW_OFFSET = 15f;

    public static CameraController Instance { get; private set;}
    private Vector3 targetFollowOffset;
    private CinemachineTransposer cinemachineTransposer;

    private void Awake()
    {
        Instance = this;
    }
    void Start()
    {
        cinemachineTransposer = cinemachineVirtualCamera.GetCinemachineComponent<CinemachineTransposer>();
        targetFollowOffset = cinemachineTransposer.m_FollowOffset;
    }
    
    private void Update()
    {
        HandleMovement();
        HandleRotation();
        HandleZoom();
    }
    void HandleMovement()
    {
        Vector2 inputMoveDir = InputManager.Instance.GetCameraMoveVector();
        float moveSpeed = 10f;
        // 按相机角度移动
        Vector3 moveVector = transform.forward * inputMoveDir.y + transform.right * inputMoveDir.x;
        transform.position += moveVector.normalized * moveSpeed * Time.deltaTime;
    }

    void HandleRotation()
    {
        Vector3 rotationVector = new Vector3(0, 0, 0);
        rotationVector.y = InputManager.Instance.GetCameraRotateAmount();

        float rotationSpeed = 100f;
        transform.eulerAngles += rotationVector * rotationSpeed * Time.deltaTime;
    }
    
    void HandleZoom()
    {
        float zoomIncreaseAmount = 1f;
        targetFollowOffset.y += InputManager.Instance.GetCameraZoomAmount() * zoomIncreaseAmount;

        targetFollowOffset.y = Mathf.Clamp(targetFollowOffset.y, MIN_FOLLOW_OFFSET, MAX_FOLLOW_OFFSET);
        float zoomSpeed = 5f;
        cinemachineTransposer.m_FollowOffset =
            Vector3.Lerp(cinemachineTransposer.m_FollowOffset, targetFollowOffset, Time.deltaTime * zoomSpeed);
    }

    public float GetCameraHeight()
    {
        return targetFollowOffset.y;
    }

    public void SaveCurrentState()
    {
        if (cinemachineVirtualCamera != null) 
        {
            savedState = new CameraState
            {
                Follow = cinemachineVirtualCamera.Follow,
                LookAt = cinemachineVirtualCamera.LookAt,
                Position = cinemachineVirtualCamera.transform.position,
                Rotation = cinemachineVirtualCamera.transform.rotation
            };
        }
    }

    public void RestorePreviousState()
    {
        if (savedState.HasValue)
        {
            var state = savedState.Value;

            cinemachineVirtualCamera.Follow = state.Follow;
            cinemachineVirtualCamera.LookAt = state.LookAt;

            cinemachineVirtualCamera.transform.position = state.Position;
            cinemachineVirtualCamera.transform.rotation = state.Rotation;

            savedState = null; 
        }
    }
}
